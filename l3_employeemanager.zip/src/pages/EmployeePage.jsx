  // EmployeePage.jsx
  import React, { useEffect, useState } from 'react';
  import { Container, Button, Dialog, DialogTitle, DialogContent } from '@mui/material';
  import EmployeeTable from '../component/EmployeeTable';
  import EmployeeForm from '../component/EmployeeForm';
  import RegisterProfileDialog from '../component/Dialog/RegisterProfileDialog';
  import { toast } from 'react-toastify';
  import axios from 'axios';

  const EmployeePage = () => {
    const [open, setOpen] = useState(false);
    const [editData, setEditData] = useState(null);
    const [viewData, setViewData] = useState(null);
    const [data, setData] = useState([])
    const user = JSON.parse(localStorage.getItem('user'))
    const [registerDialogOpen, setRegisterDialogOpen] = useState(false);
    const [registerData, setRegisterData] = useState({
      profile: {},
      application: {}
    });
    const [currentEmployeeId, setCurrentEmployeeId] = useState(null);
    const employeeData = data.find(data=> data.id === currentEmployeeId)

    const fetchData = async () => {
      const res = await axios.get('http://localhost:3001/employees');
      const filtered = user.role === 'leader'
        ? res.data
        : res.data.filter(data => data.createdBy === user.id);

      setData(filtered);
    };

    useEffect(() => {
      fetchData();
    }, []);

    const handleAdd = () => {
      setEditData(null);
      setOpen(true);
    };

  const handleEdit = (employee) => {
    if (user.role === 'leader') {
      setViewData(employee);
    } else {
      setEditData(employee);
      setOpen(true);
    }
  };


    const handleOpenRegisterDialog = (employee) => {
      setCurrentEmployeeId(employee.id);
      setRegisterDialogOpen(true);
    };

    const handleSubmitRegister = async (formData) => {
    try {
      const currentEmployee = data.find(emp => emp.id === currentEmployeeId);
      const payload = {
        ...currentEmployee,
        profileRecords: formData.profile,
        applicationRecords: formData.application,
      };

      await axios.put(`http://localhost:3001/employees/${currentEmployeeId}`, payload);
      toast.success("Lưu thông tin hồ sơ thành công!");
      await fetchData();
    } catch (error) {
      toast.error("Có lỗi khi lưu hồ sơ!");
    }
  };

    const handleView = (employee) => {
      setViewData(employee);
    };

    return (
      <Container>
        <h2>Danh sách nhân viên</h2>
        {user.role !== 'leader' && (
          <Button variant="contained" onClick={handleAdd}>Thêm mới</Button>
        )}

        <EmployeeTable onEdit={handleEdit} onView={handleView} employees={data} onSuccess={fetchData}/>

        <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
          <DialogTitle>{editData ? 'Chỉnh sửa' : 'Thêm mới'} Nhân viên</DialogTitle>
          <DialogContent>
            <EmployeeForm onSuccess={fetchData} editData={editData} onClose={() => setOpen(false)} onRegisterClick={handleOpenRegisterDialog} isViewMode={user.role === 'leader'}/>
          </DialogContent>
        </Dialog>

        <Dialog open={!!viewData} onClose={() => setViewData(null)} maxWidth="md" fullWidth>
          <DialogTitle>Xem chi tiết nhân viên</DialogTitle>
          <DialogContent>
            <EmployeeForm editData={viewData} isViewMode={true} onClose={() => setViewData(null)} />
          </DialogContent>
        </Dialog>
        <RegisterProfileDialog
          open={registerDialogOpen}
          onClose={() => setRegisterDialogOpen(false)}
          data={registerData}
          setData={setRegisterData}
          onSubmit={handleSubmitRegister}
          employeeData={employeeData}
        />
      </Container>
    );
  };

  export default EmployeePage;
